const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/Ckml4ADw.js","assets/Ctd_jhc1.js"])))=>i.map(i=>d[i]);
import{_ as p}from"./CtEKiMHg.js";import{registerPlugin as r}from"./Ctd_jhc1.js";const _=r("App",{web:()=>p(()=>import("./Ckml4ADw.js"),__vite__mapDeps([0,1])).then(e=>new e.AppWeb)});export{_ as App};
