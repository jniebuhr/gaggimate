import{WebPlugin as n}from"./Ctd_jhc1.js";class r extends n{async show(e){}async hide(e){}}export{r as SplashScreenWeb};
