const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/C4Nz5wVh.js","assets/Ctd_jhc1.js"])))=>i.map(i=>d[i]);
import{_ as r}from"./C1UxDPFQ.js";import{registerPlugin as o}from"./Ctd_jhc1.js";const i=o("Share",{web:()=>r(()=>import("./C4Nz5wVh.js"),__vite__mapDeps([0,1])).then(e=>new e.ShareWeb)});export{i as Share};
