const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/Bui0ybYn.js","assets/Ctd_jhc1.js"])))=>i.map(i=>d[i]);
import{_ as r}from"./Dc39rS1r.js";import{registerPlugin as o}from"./Ctd_jhc1.js";const i=o("SplashScreen",{web:()=>r(()=>import("./Bui0ybYn.js"),__vite__mapDeps([0,1])).then(e=>new e.SplashScreenWeb)});export{i as SplashScreen};
